import { useState } from 'react';
import Link from '@/router/Link';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

/**
 * Recharts' default tooltip shows only the y value. The chart is read as
 * "what was the rate on this date", so both halves are printed explicitly.
 */
function RateTooltip({ active, payload, label, pairLabel }: {
  active?: boolean;
  payload?: Array<{ value?: number | string }>;
  label?: string;
  pairLabel: string;
}) {
  if (!active || !payload?.length) return null;
  const value = Number(payload[0]?.value);
  if (!Number.isFinite(value)) return null;

  return (
    <div
      className="rounded-xl border border-[#282E38] bg-[#111418] px-3.5 py-2.5 text-[13px] text-white"
      style={{ fontVariantNumeric: 'tabular-nums' }}
    >
      <div className="text-[12px] text-[#9AA4B2]">{label}</div>
      <div className="font-semibold">
        1 {pairLabel.split('/')[0]} = {formatRate(value)} {pairLabel.split('/')[1]}
      </div>
    </div>
  );
}
import { currencies } from '@/data/currencies';
import { formatRate } from '@/lib/rates';
import { useRateHistory } from '@/lib/fx/useHistory';
import RateErrorNotice from '@/components/feedback/RateErrorNotice';
import { useLiveRates } from '@/lib/fx/RateProvider';
import { wait } from '@/lib/utils';
import { Download, Share2, Info, ArrowLeftRight } from 'lucide-react';
import LiveRateValue from '@/components/ui/LiveRateValue';
import LiveUpdatedBadge from '@/components/ui/LiveUpdatedBadge';
import DeltaChip from '@/components/ui/DeltaChip';
import ActionButton from '@/components/ui/ActionButton';
import { ChartSkeleton } from '@/components/ui/Skeleton';

export default function ChartsPage() {
  const fx = useLiveRates();
  const [fromCode, setFromCode] = useState('USD');
  const [toCode, setToCode] = useState('EUR');
  const [range, setRange] = useState<'1D' | '1W' | '1M' | '3M' | '6M' | '1Y' | '5Y' | '10Y'>('1M');
  const [swapCount, setSwapCount] = useState(0);
  const [shareError, setShareError] = useState<string | null>(null);

  const rangeDays: Record<string, number> = {
    '1D': 1,
    '1W': 7,
    '1M': 30,
    '3M': 90,
    '6M': 180,
    '1Y': 365,
    '5Y': 1825,
    '10Y': 3650,
  };

  const currentRate = fx.rate(fromCode, toCode);
  const change = fx.change(fromCode, toCode);
  const high24h = fx.high(fromCode, toCode);
  const low24h = fx.low(fromCode, toCode);

  // Real ECB history for the selected pair and range.
  const history = useRateHistory(fromCode, toCode, rangeDays[range]);
  const chartData = history.points;

  // Derived from the request itself. A separate flag previously got stranded
  // when a cached response resolved without ever painting a loading state,
  // which froze the chart on its skeleton permanently.
  const isLoadingChart = history.status === 'loading';

  const triggerLoading = (updateFn: () => void) => {
    updateFn();
  };

  const handleSwap = () => {
    setSwapCount((c) => c + 1);
    triggerLoading(() => {
      setFromCode(toCode);
      setToCode(fromCode);
    });
  };

  const handleExportCsv = async () => {
    const rows = ['date,rate', ...chartData.map((r) => `${r.date},${formatRate(r.rate)}`)].join('\n');
    const blob = new Blob([rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fromCode}-${toCode}-${range}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    await wait(300);
  };

  const handleShare = async () => {
    const shareUrl = window.location.href;
    // Only claim success when the clipboard write really happened.
    if (!navigator.clipboard?.writeText) {
      setShareError('Copying to the clipboard is not available in this browser.');
      throw new Error('clipboard unavailable');
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
    } catch {
      setShareError('Could not copy the link. Select the URL from the address bar instead.');
      throw new Error('clipboard write failed');
    }
    setShareError(null);
    await wait(250);
  };

  return (
    <div className="min-h-screen bg-bg py-10 sm:py-16">
      <div className="container-vx">
        {/* Header */}
        <div className="mb-8 space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <span className="badge-neutral">Forex Intelligence</span>
            <LiveUpdatedBadge utcTime={fx.updatedAt} />
          </div>
          <h1>Interactive FX Currency Charts</h1>
          <p className="text-ink-500">
            Historical exchange rate trends spanning up to 10 years, built on mid-market tick data.
          </p>
        </div>

        {/* Currency Pair Picker */}
        <div className="card p-4 sm:p-6 bg-surface mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div>
              <label htmlFor="charts-from" className="block mb-1.5">
                Base Currency (From)
              </label>
              <select
                id="charts-from"
                value={fromCode}
                onChange={(e) => triggerLoading(() => setFromCode(e.target.value))}
                className="select-field text-[14px] font-medium"
              >
                {currencies.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="charts-to" className="block mb-1.5">
                Quote Currency (To)
              </label>
              <select
                id="charts-to"
                value={toCode}
                onChange={(e) => triggerLoading(() => setToCode(e.target.value))}
                className="select-field text-[14px] font-medium"
              >
                {currencies.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleSwap}
              className="btn-secondary w-full justify-center"
            >
              <ArrowLeftRight
                aria-hidden="true"
                className="w-4 h-4 transition-transform duration-200 ease-fintech"
                style={{ transform: `rotate(${swapCount * 180}deg)` }}
              />
              <span>Swap Currencies</span>
            </button>

            <Link
              href={`/converter/${fromCode.toLowerCase()}-to-${toCode.toLowerCase()}`}
              className="btn-primary w-full justify-center"
            >
              Convert {fromCode} to {toCode}
            </Link>
          </div>
        </div>

        {/* Main Chart & Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
          <div className="lg:col-span-9">
            {isLoadingChart ? (
              <ChartSkeleton />
            ) : history.status === 'error' ? (
              <RateErrorNotice error={history.error} onRetry={history.reload} />
            ) : (
              <div className="card p-6 bg-surface">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-line gap-4">
                  <div>
                    <div className="text-[24px] sm:text-[32px] leading-[36px] font-heading font-semibold text-ink tabular-nums">
                      1 {fromCode} ={' '}
                      <LiveRateValue
                        value={currentRate}
                        pairKey={`${fromCode}-${toCode}`}
                        formatted={formatRate(currentRate)}
                      />{' '}
                      {toCode}
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-caption text-ink-500">
                      <DeltaChip change={change} suffix="past 24h" hasData={Boolean(fx.previousRates)} comparedTo={fx.previousDate} />
                      <span>• Mid-market rate</span>
                    </div>
                  </div>

                  {/* Time Range Tabs */}
                  <div className="flex flex-wrap rounded-xl bg-surface-subtle p-1 gap-1" role="group" aria-label="Chart period">
                    {(['1D', '1W', '1M', '3M', '6M', '1Y', '5Y', '10Y'] as const).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => triggerLoading(() => setRange(t))}
                        aria-pressed={range === t}
                        className={`px-3 min-h-[44px] text-[13px] font-medium rounded-lg transition-colors duration-150 tabular-nums ${
                          range === t
                            ? 'bg-surface text-ink border border-line'
                            : 'text-ink-500 hover:text-ink'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Recharts Area */}
                <div className="h-96 w-full pt-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E1E5EC" />
                      <XAxis
                        dataKey="date"
                        tickLine={false}
                        axisLine={false}
                        tick={{ fill: '#4B5565', fontSize: 12, fontFamily: 'var(--font-inter)' }}
                        tickFormatter={(d: string) => (['1Y', '5Y', '10Y'].includes(range) ? d : d.slice(5))}
                      />
                      <YAxis
                        domain={['auto', 'auto']}
                        tickLine={false}
                        axisLine={false}
                        tick={{ fill: '#4B5565', fontSize: 12, fontFamily: 'var(--font-inter)' }}
                        tickFormatter={(v) => formatRate(v)}
                      />
                      <Tooltip
                        content={<RateTooltip pairLabel={`${fromCode}/${toCode}`} />}
                        cursor={{ stroke: '#4B5565', strokeDasharray: '3 3' }}
                      />
                      <Area
                        type="monotone"
                        dataKey="rate"
                        stroke="#111418"
                        strokeWidth={2}
                        fill="#111418"
                        fillOpacity={0.07}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                <div className="flex flex-wrap justify-between items-center pt-4 border-t border-line gap-3 text-caption text-ink-500">
                  <span className="flex items-center gap-1.5">
                    <Info className="w-4 h-4" aria-hidden="true" />
                    <span>Highs and lows are based on mid-market rates</span>
                  </span>
                  <div className="flex flex-wrap gap-2">
                    <ActionButton variant="ghost" onAction={handleExportCsv} successLabel="Downloaded" className="btn-sm">
                      <span className="inline-flex items-center gap-1.5">
                        <Download className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Export CSV</span>
                      </span>
                    </ActionButton>
                    <ActionButton variant="ghost" onAction={handleShare} successLabel="Copied Link" className="btn-sm">
                      <span className="inline-flex items-center gap-1.5">
                        <Share2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Share</span>
                      </span>
                    </ActionButton>
                  </div>
                  {shareError && (
                    <p role="alert" className="mt-3 text-[13px] text-loss">
                      {shareError}
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Stats Sidebar */}
          <div className="lg:col-span-3 space-y-4">
            <div className="card p-5 bg-surface space-y-4">
              <h3 className="text-[18px] leading-[24px] border-b border-line pb-2">Rate Overview</h3>
              <div>
                <span className="text-caption text-ink-500 block">24h High</span>
                <span className="text-[18px] font-semibold text-ink tabular-nums">
                  {formatRate(high24h)}
                </span>
              </div>
              <div>
                <span className="text-caption text-ink-500 block">24h Low</span>
                <span className="text-[18px] font-semibold text-ink tabular-nums">
                  {formatRate(low24h)}
                </span>
              </div>
              <div>
                <span className="text-caption text-ink-500 block">Inverse (1 {toCode} =)</span>
                <span className="text-[18px] font-semibold text-ink tabular-nums">
                  {formatRate(1 / currentRate)} {fromCode}
                </span>
              </div>
              <div className="pt-2">
                <Link
                  href={`/converter/${fromCode.toLowerCase()}-to-${toCode.toLowerCase()}`}
                  className="btn-primary w-full justify-center btn-sm"
                >
                  Convert {fromCode} to {toCode}
                </Link>
              </div>
            </div>

            <div className="card-invert p-5 space-y-3">
              <h3 className="text-[18px] leading-[24px] text-ink-invert">Need the raw numbers?</h3>
              <p className="text-[14px] leading-[22px] text-ink-invert-muted">
                Download the full published series for {fromCode}/{toCode} as a CSV and work with it in your own spreadsheet.
              </p>
              <Link href="/historical" className="btn-invert btn-sm w-full justify-center">
                Open Historical Data
              </Link>
            </div>
          </div>
        </div>

        {/* Historical Table Preview */}
        <div className="card p-6 bg-surface">
          <h3 className="mb-4">
            Recent {fromCode} to {toCode} Historical Close Rates
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-surface-subtle text-caption font-medium text-ink-500 uppercase border-b border-line">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Close Rate</th>
                  <th className="py-3 px-4">Estimated 100 {fromCode}</th>
                  <th className="py-3 px-4">Inverse Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line tabular-nums">
                {chartData.slice(-7).reverse().map((row) => (
                  <tr key={row.date} className="hover:bg-surface-subtle/60">
                    <td className="py-3 px-4 font-medium text-ink">{row.date}</td>
                    <td className="py-3 px-4 font-semibold text-ink">{formatRate(row.rate)}</td>
                    <td className="py-3 px-4 text-ink-700">
                      {formatRate(100 * row.rate)} {toCode}
                    </td>
                    <td className="py-3 px-4 text-ink-500">
                      {formatRate(1 / row.rate)} {fromCode}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
